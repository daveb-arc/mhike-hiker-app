enum MenuAction { logout }

enum HikeMenu { update, delete }