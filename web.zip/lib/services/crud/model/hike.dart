import 'package:cloud_firestore/cloud_firestore.dart';

class Hike {
  final String? id;
  final String title;
  final String location;
  final double length;
  final String estimatedTime;
  final String description;
  final bool parking;
  final String difficulty;
  final DateTime date;
  final String? coverImageUrl;

  Hike({
    this.id,
    required this.title,
    required this.location,
    required this.length,
    required this.estimatedTime,
    required this.description,
    required this.parking,
    required this.difficulty,
    required this.date,
    this.coverImageUrl,
  });

  // ---------- FIRESTORE WRITE ----------
  Map<String, dynamic> toMap() {
    return {
      'title': title,
      'location': location,
      'length': length,
      'estimatedTime': estimatedTime,
      'description': description,
      'parking': parking,
      'difficulty': difficulty,
      'date': Timestamp.fromDate(date),
      'coverImageUrl': coverImageUrl,
      'createdAt': FieldValue.serverTimestamp(),
    };
  }

  // ---------- FIRESTORE READ ----------
  factory Hike.fromDoc(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;

    return Hike(
      id: doc.id,
      title: data['title'] ?? '',
      location: data['location'] ?? '',
      length: (data['length'] ?? 0).toDouble(),
      estimatedTime: data['estimatedTime'] ?? '',
      description: data['description'] ?? '',
      parking: data['parking'] ?? false,
      difficulty: data['difficulty'] ?? '',
      date: (data['date'] as Timestamp?)?.toDate() ?? DateTime.now(),
      coverImageUrl: data['coverImageUrl'],
    );
  }
}
