import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:mhike/services/crud/model/hike.dart';
import 'package:mhike/services/crud/model/comment.dart';
import 'package:mhike/services/crud/model/observation.dart';
import 'package:mhike/services/crud/model/picture.dart';

class MHikeService {
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  // ---------------- HIKES ----------------

  Future<void> createHike(Hike hike) async {
    await _db.collection('hikes').add(hike.toMap());
  }

  Stream<List<Hike>> allHikes() {
    return _db.collection('hikes').snapshots().map(
          (snapshot) =>
              snapshot.docs.map((doc) => Hike.fromDoc(doc)).toList(),
        );
  }

  // ---------------- COMMENTS ----------------

  Stream<List<Comment>> commentsForHike(String hikeId) {
    return _db
        .collection('hikes')
        .doc(hikeId)
        .collection('comments')
        .orderBy('createdAt', descending: true)
        .snapshots()
        .map(
          (snapshot) =>
              snapshot.docs.map((doc) => Comment.fromDoc(doc)).toList(),
        );
  }

  Future<void> addComment({
    required String hikeId,
    required String userId,
    required String userEmail,
    required String text,
  }) async {
    await _db
        .collection('hikes')
        .doc(hikeId)
        .collection('comments')
        .add({
      'userId': userId,
      'userEmail': userEmail,
      'text': text,
      'createdAt': FieldValue.serverTimestamp(),
    });
  }

  // ---------------- OBSERVATIONS ----------------

  Stream<List<Observation>> observationsForHike(String hikeId) {
    return _db
        .collection('hikes')
        .doc(hikeId)
        .collection('observations')
        .orderBy('createdAt', descending: true)
        .snapshots()
        .map(
          (snapshot) =>
              snapshot.docs.map((doc) => Observation.fromDoc(doc)).toList(),
        );
  }

  Future<void> addObservation({
    required String hikeId,
    required Observation observation,
  }) async {
    await _db
        .collection('hikes')
        .doc(hikeId)
        .collection('observations')
        .add(observation.toMap());
  }

  // ---------------- PICTURES ----------------

  Stream<List<Picture>> picturesForHike(String hikeId) {
    return _db
        .collection('hikes')
        .doc(hikeId)
        .collection('pictures')
        .orderBy('createdAt', descending: true)
        .snapshots()
        .map(
          (snapshot) =>
              snapshot.docs.map((doc) => Picture.fromDoc(doc)).toList(),
        );
  }

  Future<void> addPicture({
    required String hikeId,
    required Picture picture,
  }) async {
    await _db
        .collection('hikes')
        .doc(hikeId)
        .collection('pictures')
        .add(picture.toMap());
  }
}
