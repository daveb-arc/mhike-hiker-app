import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:intl/intl.dart';
import 'package:mhike/services/auth/auth_service.dart';
import 'package:mhike/services/crud/m_hike_service.dart';
import 'package:mhike/services/crud/model/comment.dart';
import 'package:mhike/services/crud/model/hike.dart';

class CommentTab extends StatefulWidget {
  final Hike hike;
  const CommentTab({super.key, required this.hike});

  @override
  State<CommentTab> createState() => _CommentTabState();
}

class _CommentTabState extends State<CommentTab> {
  final MHikeService _mHikeService = MHikeService();
  final TextEditingController _commentController = TextEditingController();

  double _rating = 3.0; // UI only
  bool _saving = false;

  @override
  void dispose() {
    _commentController.dispose();
    super.dispose();
  }

  Future<void> _addComment() async {
    final hikeId = widget.hike.id;
    if (hikeId == null || hikeId.isEmpty) return;

    final user = AuthService.firebase().currentUser;
    if (user == null) return;

    final text = _commentController.text.trim();
    if (text.isEmpty) return;

    setState(() => _saving = true);

    try {
      // ✅ MATCHES SERVICE SIGNATURE EXACTLY
      await _mHikeService.addComment(
        hikeId: hikeId,
        userId: user.id,
        userEmail: user.email,
        text: text,
      );

      if (!mounted) return;
      _commentController.clear();
      FocusScope.of(context).unfocus();
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final hikeId = widget.hike.id;
    if (hikeId == null) {
      return const Center(child: Text('Missing hike id'));
    }

    return Column(
      children: [
        Expanded(
          child: StreamBuilder<List<Comment>>(
            stream: _mHikeService.commentsForHike(hikeId),
            builder: (context, snapshot) {
              if (snapshot.hasError) {
                return Center(child: Text('Error: ${snapshot.error}'));
              }
              if (!snapshot.hasData) {
                return const Center(child: CircularProgressIndicator());
              }

              final comments = snapshot.data!;
              if (comments.isEmpty) {
                return const Center(child: Text('No comments yet'));
              }

              return ListView.separated(
                padding: const EdgeInsets.all(12),
                itemCount: comments.length,
                separatorBuilder: (_, __) => const Divider(height: 16),
                itemBuilder: (context, index) {
                  final c = comments[index];
                  return Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: const Color.fromARGB(255, 55, 59, 87),
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Expanded(
                              child: Text(
                                c.userEmail,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                            ),
                            const SizedBox(width: 8),
                            Text(
                              DateFormat('y-MM-dd').format(c.dateTime),
                              style: const TextStyle(color: Colors.grey),
                            ),
                          ],
                        ),
                        const SizedBox(height: 8),
                        Text(c.text),
                      ],
                    ),
                  );
                },
              );
            },
          ),
        ),

        // INPUT AREA
        Container(
          padding: const EdgeInsets.fromLTRB(12, 10, 12, 12),
          color: const Color(0xff282b41),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // Rating kept for future use (not persisted yet)
              RatingBar.builder(
                initialRating: _rating,
                minRating: 1,
                allowHalfRating: true,
                itemCount: 5,
                itemSize: 26,
                itemBuilder: (context, _) =>
                    const Icon(Icons.star, color: Colors.amber),
                onRatingUpdate: (val) => setState(() => _rating = val),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: _commentController,
                minLines: 1,
                maxLines: 3,
                decoration: const InputDecoration(
                  hintText: 'Write a comment...',
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 10),
              ElevatedButton(
                onPressed: _saving ? null : _addComment,
                child: _saving
                    ? const SizedBox(
                        height: 18,
                        width: 18,
                        child: CircularProgressIndicator(strokeWidth: 2),
                      )
                    : const Text('Post Comment'),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
