const loginRoute = '/login/';
const signupRoute = '/register/';
const homeRoute = '/home/';
const searchRoute = '/search/';
const addHikeRoute = '/add-hike/';
const hikeDetailRoute = '/hike-detail/';